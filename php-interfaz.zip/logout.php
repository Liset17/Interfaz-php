<?php
// =============================================================
// logout.php
// -------------------------------------------------------------
// Destruye la sesion y redirige al login. Solo acepta POST
// para evitar cierres de sesion accidentales desde un enlace.
// =============================================================

require __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(url('home.php'));
}

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();
redirect(url('login.php'));
